# Material Service

This amazon lambda service builds a material library that is sent to printer. Material file includes name, material type, brand, print temperature, speed override and retraction parameters for each material. Printer then uses this information to adjust temperature and other settings when printing.
